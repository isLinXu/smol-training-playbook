import{b as r}from"./_baseUniq.3C7VNVAK.js";var e=4;function a(o){return r(o,e)}export{a as c};
